package com.example.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dao.ClaimRepository;
import com.example.dao.CustomerRepository;
import com.example.dao.PolicyRepository;
import com.example.model.Claim;
import com.example.model.Customer;
import com.example.model.Policy;

@Service
public class ClaimService {
	
	@Autowired
	private ClaimRepository claimRepo;
	
	@Autowired
	private CustomerRepository customerRepo;
	
	@Autowired
	private PolicyRepository policyRepo;

	public List<Claim> getAllClaimData() {
		return claimRepo.findAll();
	}

	public Claim saveClaimData(Claim claim) {	    
	    
	    return claimRepo.save(claim);

	}

//	public Claim updateClaimData(Long claimId, Claim claim) {
//		
//		Optional<Claim> existingData = claimRepo.findById(claimId);
//		if(existingData.isPresent()) {
//			Claim existingClaim = existingData.get();
//			existingClaim.setPolicy(claim.getPolicy());
//		    return claimRepo.save(claim);
//		}else {
//			return null;
//		}
//	}
	public Claim updateClaimData(Long claimId, Claim claimDetails) {
	    Optional<Claim> existingData = claimRepo.findById(claimId);
	    if (existingData.isPresent()) {
	        Claim existingClaim = existingData.get();


	        existingClaim.setClaimAmount(claimDetails.getClaimAmount());
	        existingClaim.setStatus(claimDetails.getStatus());

	       
	        if (claimDetails.getPolicy() != null) {
	            Policy policy = policyRepo.findById(claimDetails.getPolicy().getPolicyID())
	                    .orElseThrow();
	            existingClaim.setPolicy(policy);
	        }

	       
	        if (claimDetails.getCustomer() != null) {
	            Customer customer = customerRepo.findById(claimDetails.getCustomer().getCustomerID())
	                    .orElseThrow();
	            existingClaim.setCustomer(customer);
	        }

	       
	        return claimRepo.save(existingClaim);
	    } else {
	        return null;
	    }
	}

	

}
