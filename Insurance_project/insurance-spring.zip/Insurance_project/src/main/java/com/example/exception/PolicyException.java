package com.example.exception;

public class PolicyException extends RuntimeException{

	public PolicyException(String s)
	{
		super(s);
	}
}
