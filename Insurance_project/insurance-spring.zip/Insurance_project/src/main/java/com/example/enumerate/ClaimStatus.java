package com.example.enumerate;

public enum ClaimStatus {
	
	FILED,UNDER_REVIEW,APPROVED,REJECTED

}
