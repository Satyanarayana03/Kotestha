package com.example.exception;

public class CustomerException extends RuntimeException {

	public CustomerException(String s)
	{
		super(s);
	}
}
